from SV_CanNoPatch.CanNoPatch import VersionCanNoPatch
