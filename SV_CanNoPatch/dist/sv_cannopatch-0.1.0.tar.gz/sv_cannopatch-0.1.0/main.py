def main():
    print("Hello from sv-cannopatch!")


if __name__ == "__main__":
    main()
